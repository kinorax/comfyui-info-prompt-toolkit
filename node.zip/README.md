[English](README.md) | [日本語](README.ja.md)

# ComfyUI-Info-Prompt-Toolkit

This extension node collection is built around simplifying ComfyUI wiring and improving reusability, so trial results are easier to carry into the next production pass.  
Key features include Civitai-compatible image metadata saving, same-name `.txt` caption saving, XY Plot, Tiled Sampling (`SDXL (with ControlNet Tile)` and `Anima`), SAM3, Detailer, PixAI Tagger, OppaiOracle Tagger, wildcards, and Dynamic Prompts to strengthen your workflow.

## Installation

```bash
cd ComfyUI/custom_nodes
git clone https://github.com/kinorax/comfyui-info-prompt-toolkit.git
cd comfyui-info-prompt-toolkit
pip install -r requirements.txt
```
Installing via ComfyUI Manager is the easiest option.

> Note: `SAM3 Prompt To Mask`, `PixAI Tagger`, and `OppaiOracle Tagger` require manual placement of model files under `ComfyUI/models` after installation. See the relevant sections in `Core Nodes` for details.

## Support Ongoing Development

A paid note article is available for users who want polished results with less trial and error. It introduces production-oriented SDXL and Anima workflows built with these custom nodes. Purchasing the article helps support ongoing development.

Article: [ComfyUI SDXL & Anima Workflow: Automatic Detailer, XY Plot, Caption File Generation, and More](https://note.com/vast_zinnia5253/n/n95a43362d467?hl=en)

The workflow files use English labels throughout.

## Core Nodes

### SamplerCustom (Sampler Params, Tiled) / SamplerCustom (Sampler Params)

<a href="assets/readme/samplercustom-sampler-params-pair.webp"><img align="left" hspace="16" src="assets/readme/samplercustom-sampler-params-pair.webp" alt="SamplerCustom pair" width="210"></a>
<ul>
  <li>Accepts <code>sampler_params</code> and performs sampling using the official <code>KSamplerSelect</code> / <code>BasicScheduler</code> / <code>SamplerCustom</code> nodes (no custom sampling logic is implemented).</li>
  <li>The Tiled version uses the same sampling settings as the standard version and runs inference by splitting into spatial tiles.</li>
  <li>The Tiled version is useful not only under VRAM constraints, but also when you need output resolutions beyond a model's practical supported size.</li>
  <li>Models with verified operation for the Tiled version are currently <code>SDXL (with ControlNet Tile)</code> and <code>Anima</code>. Other models may still work, but compatibility is not guaranteed.</li>
</ul>
<br clear="left">

### Sampler Params

<a href="assets/readme/sampler-params.webp"><img align="left" hspace="16" src="assets/readme/sampler-params.webp" alt="Sampler Params" width="210"></a>
<ul>
  <li>Aggregates sampler/scheduler/steps/denoise/seed/cfg into a single <code>sampler_params</code> bundle.</li>
  <li>Improves both wiring simplicity and configuration reuse.</li>
</ul>
<br clear="left">

### XY Plot Start / XY Plot Modifier / XY Plot End

<a href="assets/readme/xy-plot-start-modifier-end.webp"><img align="left" hspace="16" src="assets/readme/xy-plot-start-modifier-end.webp" alt="XY Plot nodes" width="210"></a>
<ul>
  <li><code>XY Plot Modifier</code> chains axis-specific change sets (<code>label</code> + <code>changes</code>) as an array and defines X/Y condition variations.</li>
  <li><code>XY Plot Start</code> applies X/Y modifiers to the base <code>image_info</code>, generates per-cell <code>image_info</code>, and outputs in <code>list</code> (all at once) or <code>loop</code> (iterative) mode.</li>
  <li><code>XY Plot End</code> receives <code>xy_plot_info</code> and generated images, then composes the axis-labeled grid image <code>xy_plot_image</code>.</li>
  <li>In <code>loop</code> mode, <code>Start</code> and <code>End</code> cooperate via <code>loop_control</code> to process all cells sequentially.</li>
</ul>
<br clear="left">

### Image Info Context

<a href="assets/readme/image-info-context.webp"><img align="left" hspace="16" src="assets/readme/image-info-context.webp" alt="Image Info Context" width="210"></a>
<ul>
  <li><code>Image Info Context</code> reconstructs updated <code>image_info</code> by reflecting only the input fields that are actually connected.</li>
  <li>When <code>positive</code> is connected, it extracts <code>&lt;lora:...:...&gt;</code> tags and applies the tag-removed <code>positive</code> text and extracted values to <code>lora_stack</code>.</li>
  <li><code>extras</code> is merged into existing <code>image_info.extras</code>, and duplicate keys are overwritten by input-side values.</li>
  <li>In addition to updated fields, it outputs <code>base_sampler_params</code> (with fixed <code>denoise=1.0</code>) for easy connection to downstream sampling nodes.</li>
</ul>
<br clear="left">

### Image Info Fallback

<a href="assets/readme/image-info-fallback.webp"><img align="left" hspace="16" src="assets/readme/image-info-fallback.webp" alt="Image Info Fallback" width="210"></a>
<ul>
  <li><code>Image Info Fallback</code> fills missing fields in the primary <code>image_info</code> from <code>image_info_fallback</code>.</li>
  <li>Fallback is limited to missing fields, and fields that already have values in the primary side are not overwritten.</li>
  <li><code>extras</code> is merged by adding only missing keys, while existing keys are preserved.</li>
  <li><code>lora_stack</code> is supplemented when it is missing or <code>None</code>; an explicit empty list means no LoRA and is preserved.</li>
</ul>
<br clear="left">

### Detailer Start / Detailer End

<a href="assets/readme/detailer-start-end.webp"><img align="left" hspace="16" src="assets/readme/detailer-start-end.webp" alt="Detailer Start and End" width="210"></a>
<ul>
  <li><code>Detailer Start</code> detects a <code>bounding box (bbox)</code> from regions where the input <code>mask</code> value is greater than <code>0.0</code>, then creates an expanded processing region using <code>crop_margin_scale</code>.</li>
  <li>The processing region is pre-upscaled by <code>upscale_factor</code>, then rounded up to a size divisible by <code>mini_unit</code> (8/16/32/64) and arranged with <code>center padding</code>.</li>
  <li>For compositing back into the original image, the graded values of the input <code>mask</code> are preserved as a <code>soft mask</code>, and that information is stored in <code>detailer_control</code>.</li>
  <li><code>Detailer End</code> receives <code>inpainted_image</code> and <code>composite</code>s it back into the original image using the preserved <code>soft mask</code>.</li>
  <li>If <code>inpainted_image</code> resolution differs from the expected <code>canvas</code> size, it is automatically resized before restoration.</li>
  <li>If no target region is detected, <code>Detailer End</code> does not evaluate <code>inpainted_image</code> and returns the original image unchanged.</li>
</ul>
<br clear="left">

### SAM3 Prompt To Mask

<a href="assets/readme/sam3-prompt-to-mask.webp"><img align="left" hspace="16" src="assets/readme/sam3-prompt-to-mask.webp" alt="SAM3 Prompt To Mask" width="210"></a>
<ul>
  <li><code>SAM3 Prompt To Mask</code> is a single-purpose node that generates a <code>soft mask</code> from text prompts. Comma-separated <code>prompt</code> tokens are treated as OR conditions, and accepted results can be controlled with <code>score_threshold</code> and <code>combine_mode</code> (<code>union</code> / <code>top1</code>).</li>
  <li>The output is a non-binarized <code>soft mask</code>; thresholding and region cleanup are intended to be handled by downstream nodes.</li>
  <li>This node is designed with a strong focus on keeping additional <code>pip</code>-installed dependencies to a minimum, because some existing SAM3-related extensions can significantly alter Python environments.</li>
  <li>Under that policy, SAM3-related functionality is intentionally limited to this single purpose, and no further feature additions are planned at this time.</li>
  <li>Place <code>sam3.pt</code> in <code>ComfyUI/models/sam3</code> (download: <a href="https://huggingface.co/facebook/sam3">facebook/sam3</a>; operation with SAM3.1 and later is unverified).</li>
</ul>
<br clear="left">

### PixAI Tagger

<a href="assets/readme/pixai-tagger.webp"><img align="left" hspace="16" src="assets/readme/pixai-tagger.webp" alt="PixAI Tagger" width="210"></a>
<ul>
  <li><code>PixAI Tagger</code> estimates tags from images and outputs <code>general</code> / <code>character</code> / <code>ip</code>.</li>
  <li>Tag selection uses <code>threshold_general</code> / <code>threshold_character</code> and <code>max_tags_general</code> / <code>max_tags_character</code>.</li>
  <li><code>sort_order</code> controls the final display order for <code>general</code> tags only (<code>score</code> / <code>tag_id</code>); <code>character</code> and <code>ip</code> are always output in score order.</li>
  <li>This node runs on a PyTorch implementation and does not depend on <code>onnxruntime</code> / <code>onnxruntime-gpu</code>, making the setup less susceptible to Python environment changes.</li>
  <li>Place the PixAI Tagger v0.9 bundle (<code>model_v0.9.pth</code> / <code>tags_v0.9_13k.json</code> / <code>char_ip_map.json</code>) in <code>ComfyUI/models/pixai_tagger</code> or <code>ComfyUI/models/pixai_tagger/v0.9</code> (download: <a href="https://huggingface.co/pixai-labs/pixai-tagger-v0.9">pixai-labs/pixai-tagger-v0.9</a>).</li>
  <li>The previous released node remains available as <code>PixAI Tagger (Deprecated)</code> for existing workflows.</li>
</ul>
<br clear="left">

### OppaiOracle Tagger

<a href="assets/readme/oppai-oracle-tagger.webp"><img align="left" hspace="16" src="assets/readme/oppai-oracle-tagger.webp" alt="OppaiOracle Tagger" width="210"></a>
<ul>
  <li><code>OppaiOracle Tagger</code> estimates tags from images and outputs <code>tags</code> / <code>rating</code>.</li>
  <li>Tag selection uses <code>threshold</code> and <code>max_tags</code>; <code>sort_order</code> controls only the final display order (<code>score</code> / <code>tag_id</code>).</li>
  <li>This node runs on a PyTorch implementation and does not depend on <code>onnxruntime</code> / <code>onnxruntime-gpu</code>, making the setup less susceptible to Python environment changes.</li>
  <li>Place the OppaiOracle bundle (<code>model.safetensors</code> / <code>config.json</code> / <code>preprocessing.json</code> / <code>vocabulary.json</code>) in <code>ComfyUI/models/oppai_oracle/V1.1</code> or <code>ComfyUI/models/oppai_oracle/V1.0</code> (download: <a href="https://huggingface.co/Grio43/OppaiOracle">Grio43/OppaiOracle</a>).</li>
</ul>
<br clear="left">

### Flatten Prompt for Caption / Merge Caption Tokens / Remove Caption Tokens

<a href="assets/readme/caption-nodes.webp"><img align="left" hspace="16" src="assets/readme/caption-nodes.webp" alt="Caption nodes" width="210"></a>
<ul>
  <li><code>Flatten Prompt for Caption</code> prepares prompt text for caption files by removing prompt emphasis syntax and weight values, then unescaping escaped parentheses and backslashes.</li>
  <li><code>Merge Caption Tokens</code> merges <code>start</code> and <code>end</code> caption token strings, removes duplicate tokens, and rebuilds the result as a single-line caption.</li>
  <li>Caption tokens are split on <code>, </code> and <code>. </code>. Existing order is preserved, and the first occurrence of each token is kept.</li>
  <li><code>Remove Caption Tokens</code> removes exact token matches from <code>string</code> using the comma-separated <code>remove</code> input, while preserving the remaining token order.</li>
  <li>These nodes are useful when combining tagger output, handwritten captions, and prompt text before writing caption files.</li>
</ul>
<br clear="left">

### Prompt Template

<a href="assets/readme/prompt-template.webp"><img align="left" hspace="16" src="assets/readme/prompt-template.webp" alt="Prompt Template" width="210"></a>
<ul>
  <li><code>Prompt Template</code> generates final prompts from template text. It handles <code>//</code> / <code>/*...*/</code> comment removal, wildcard expansion, Dynamic Prompts expansion, and <code>$key</code> replacement in one node.</li>
  <li>Wildcards are loaded from <code>ComfyUI/user/info_prompt_toolkit/wildcards</code> <code>.txt</code> files and support <code>__name__</code> (random) and <code>__name__#N</code> (fixed selection), including weighted lines in <code>weight::value</code> format.</li>
  <li>Dynamic Prompts supports <code>{a|b}</code> plus weighted options, multi-select, range selection, and the <code>@</code> cycle sampler.</li>
  <li>When <code>seed</code> is connected, random expansion becomes reproducible; without it, results are non-deterministic.</li>
  <li>When <code>extras</code> is connected, <code>$key</code> placeholders are replaced while missing keys are left as-is. <code>suffix</code> is appended after template expansion.</li>
  <li>Outputs include raw <code>string</code> and token-normalized <code>normalized_string</code>.</li>
</ul>
<br clear="left">

### Image Reader / Image Saver

<a href="assets/readme/image-reader-and-image-saver.webp"><img align="left" hspace="16" src="assets/readme/image-reader-and-image-saver.webp" alt="Image Reader and Image Saver" width="210"></a>
<ul>
  <li><code>Image Reader</code> and <code>Image Saver</code> are core nodes that support reusable workflows for images that retain generation data (<code>A1111 infotext</code> / <code>image_info</code>).</li>
  <li><code>Image Saver</code> can save WebP or PNG images and embeds <code>A1111 infotext</code> into matching image metadata so prompt, model, and multiple LoRA references remain reusable.</li>
  <li><code>Check Referenced Models...</code> in the <code>Image Reader</code> right-click menu parses referenced entries from image infotext and lists Model / Refiner / Detailer / CLIP / VAE / LoRA items.</li>
  <li>The same window also shows local availability for each reference (Present / Missing), and can jump to <code>View Model Info...</code> for deeper inspection.</li>
  <li><code>Image Saver</code> supports both automatic serial naming and explicit <code>file_stem</code> naming, so you can switch naming strategy by workflow.</li>
  <li>When <code>write_caption</code> is enabled, a same-name <code>.txt</code> caption file is written alongside each image.</li>
</ul>
<br clear="left">

### Referenced Image Saver

<a href="assets/readme/referenced-image-saver.webp"><img align="left" hspace="16" src="assets/readme/referenced-image-saver.webp" alt="Referenced Image Saver" width="210"></a>
<ul>
  <li><code>Referenced Image Saver</code> copies an existing file supplied through <code>image_reference</code> into the ComfyUI output directory and rewrites its A1111 infotext metadata from <code>image_info</code> without re-encoding the image pixels.</li>
  <li>It supports PNG / WebP / JPEG metadata updates and preserves the source extension, making it useful for saving lossy WebP or JPEG images again without further quality loss.</li>
  <li>When <code>file_stem</code> is unconnected, it uses the same automatic serial naming as <code>Image Saver</code>. When connected, it saves as <code>&lt;file_stem&gt;&lt;source extension&gt;</code> and overwrites an existing file with the same name.</li>
  <li><code>output_subdir</code> can organize files by date, and enabling <code>write_caption</code> writes a same-name <code>.txt</code> caption alongside each image.</li>
</ul>
<br clear="left">

### Image Directory Reader

<a href="assets/readme/image-directory-reader.webp"><img align="left" hspace="16" src="assets/readme/image-directory-reader.webp" alt="Image Directory Reader" width="210"></a>
<ul>
  <li><code>Image Directory Reader</code> loads multiple images from subdirectories under ComfyUI <code>input</code> / <code>output</code> and returns corresponding data as aligned list outputs.</li>
  <li>You can choose the source with <code>path_source</code> and <code>path</code> (relative directory), then control the selection range with <code>start_index</code> and <code>image_load_limit</code> (<code>0</code> = unlimited).</li>
  <li>Target images are selected after case-insensitive filename sorting, making batch selection results easier to reproduce.</li>
  <li>For each image, it outputs <code>image</code>, <code>image_info</code> reconstructed and normalized from A1111 infotext, extensionless filename <code>file_stem</code>, and same-name <code>.txt</code> <code>caption</code> (empty string when missing).</li>
  <li>It also outputs <code>path_source</code> and <code>path</code>, so it can be connected directly to <code>Caption File Saver</code>.</li>
</ul>
<br clear="left">

### Video Reader / Video Saver

<a href="assets/readme/video-reader-and-video-saver.webp"><img align="left" hspace="16" src="assets/readme/video-reader-and-video-saver.webp" alt="Video Reader and Video Saver" width="210"></a>
<ul>
  <li><code>Video Reader</code> and <code>Video Saver</code> are a paired set of nodes that support video reuse workflows while retaining generation metadata (<code>source_image_info</code> / <code>video_info</code>).</li>
  <li><code>Video Reader</code> outputs <code>image</code> as a list. If downstream nodes expect batch-oriented image input or do not assume list expansion, route through <code>Image List To Batch</code>.</li>
  <li>In <code>Video Saver</code>, the active <code>crf</code> field controls the quality/file-size tradeoff; lower values generally produce higher quality and larger files.</li>
  <li><code>source_image_info</code> keeps source-image information, while <code>video_info</code> keeps video-related information for easier review and comparison later.</li>
  <li><code>Video Reader</code> / <code>Video Saver</code> are available in environments where <code>PyAV</code> (<code>av</code>) is installed. Available codecs depend on the user's PyAV / FFmpeg build.</li>
</ul>
<br clear="left">

### Mask Overlay Comparer

<a href="assets/readme/mask-overlay-comparer.webp"><img align="left" hspace="16" src="assets/readme/mask-overlay-comparer.webp" alt="Mask Overlay Comparer" width="210"></a>
<ul>
  <li><code>Mask Overlay Comparer</code> displays a slider-based comparison between the original <code>image</code> and a mask-overlayed view, making mask coverage easier to inspect visually.</li>
  <li>The comparer switches between two views: an easier-to-read background image and the image with mask overlay applied.</li>
  <li>The <code>mask</code> is visualized without binarization, using raw values in the <code>0.0..1.0</code> range.</li>
  <li>Visualization behavior is: <code>mask = 0.0</code> keeps the image unchanged, <code>mask = 1.0</code> renders black, and intermediate values are shown as a blue-tinted overlay.</li>
  <li>For preview generation, use <code>image</code> and <code>mask</code> at the same resolution.</li>
</ul>
<br clear="left">

### Aspect Ratio to Size

<a href="assets/readme/aspect-ratio-to-size.webp"><img align="left" hspace="16" src="assets/readme/aspect-ratio-to-size.webp" alt="Aspect Ratio to Size" width="210"></a>
<ul>
  <li><code>Aspect Ratio to Size</code> recalculates <code>width</code> / <code>height</code> from node-UI widget edits before execution, so you can adjust values while checking <code>actual_ratio</code>.</li>
  <li>It resolves size from <code>width_ratio : height_ratio</code> and a base size, using either <code>width</code> or <code>height</code> as the anchor and deriving the other side from the ratio.</li>
  <li>The resolved size is aligned to <code>min_unit</code> (8 / 16 / 32 / 64), which helps keep resolutions on practical step sizes.</li>
  <li><code>width x height</code> is a combined size output that carries width and height on a single line, making it easy to pass into nodes that accept size input.</li>
</ul>
<br clear="left">

### Aspect Ratio to Size (Trim Margin) / Trim Image by Margin

<a href="assets/readme/trim-margin-nodes.webp"><img align="left" hspace="16" src="assets/readme/trim-margin-nodes.webp" alt="Aspect Ratio to Size (Trim Margin) and Trim Image by Margin" width="210"></a>
<ul>
  <li><code>Aspect Ratio to Size (Trim Margin)</code> calculates a sampling size that extends beyond the desired image edges so that <code>Trim Image by Margin</code> can remove the margins afterward. The horizontal and vertical margin pairs stay linked, with each pair totaling either zero or <code>min_unit</code>. Its size outputs include all four margins and remain divisible by <code>min_unit</code>.</li>
  <li>Edit <code>actual_width</code> / <code>actual_height</code> as the size remaining after trimming. The readonly <code>width</code> / <code>height</code> fields show the sampling size including margins, while <code>actual_ratio</code> describes the trimmed size.</li>
  <li>The <code>margin</code> output bundles <code>top</code>, <code>right</code>, <code>bottom</code>, and <code>left</code> for <code>Trim Image by Margin</code>. When <code>margin</code> is unconnected, the trim node passes the image through unchanged.</li>
  <li><code>Set Margin Extra</code> / <code>Get Margin Extra</code> store margins in image-info extras and restore both the bundled margin and its four edge values.</li>
</ul>
<br clear="left">

### Load New Model / Use Loaded Model

<a href="assets/readme/load-new-model-and-use-loaded-model.webp"><img align="left" hspace="16" src="assets/readme/load-new-model-and-use-loaded-model.webp" alt="Load New Model and Use Loaded Model" width="210"></a>
<ul>
  <li><code>Load New Model</code> and <code>Use Loaded Model</code> are a paired workflow that separates model loading from model reuse.</li>
  <li><code>Load New Model</code> receives the selected model from selector nodes such as <code>Checkpoint Selector</code> or <code>Diffusion Model Selector</code>. Checkpoint selections can load <code>model</code>, <code>clip</code>, and <code>vae</code> from the checkpoint; diffusion model selections load the <code>model</code> and use the optional <code>clip</code>, <code>vae</code>, and <code>vae_fallback</code> inputs for the accompanying CLIP/VAE runtime. It uses a temporary strong cache only within the same prompt execution to avoid duplicate raw loads.</li>
  <li><code>Use Loaded Model</code> keeps the final runtime bundle in a process-local cache keyed by the selected model, runtime settings, <code>lora_stack</code>, and connected <code>clip</code> / <code>vae</code> conditions. On cache hit, the lazy <code>loaded_model</code> / <code>loaded_clip</code> / <code>loaded_vae</code> branch is skipped.</li>
  <li><code>Use Loaded Model</code> applies <code>lora_stack</code> internally by default. Set <code>apply_lora_stack</code> to <code>false</code> if <code>loaded_model</code> and <code>loaded_clip</code> already include the same LoRA application.</li>
  <li>If you want to pass through <code>Lora Stack Lorader</code> or <code>TorchCompile</code>-related nodes before <code>Use Loaded Model</code>, place them after <code>Load New Model</code>, then connect their outputs to <code>loaded_model</code>, <code>loaded_clip</code>, and <code>loaded_vae</code> with <code>apply_lora_stack=false</code>.</li>
  <li>Cache behavior is configurable in <code>ComfyUI Settings &gt; Info-Prompt-Toolkit &gt; Use Loaded Model Cache</code>. <code>Auto</code> always keeps the latest entry and prunes older entries by estimated memory size and <code>Memory budget ratio</code>; <code>Fixed</code> keeps up to <code>Max cache entries</code> regardless of the memory budget. <code>Max cache entries</code> defaults to <code>1</code> and can be set from <code>1</code> to <code>9</code>.</li>
  <li><code>Use cache logging</code> prints cache hit / miss / store / evict / clear messages to the ComfyUI Python console, including estimated memory amounts for store and evict events.</li>
  <li><code>lora_stack</code> matching is order- and strength-sensitive, so changing order or values is treated as a different condition set.</li>
</ul>
<br clear="left">

### Model Merge

<a href="assets/readme/model-merge.webp"><img align="left" hspace="16" src="assets/readme/model-merge.webp" alt="Model Merge" width="210"></a>
<ul>
  <li><code>Model Merge</code> records two <code>IPT-Model</code> selections and their merge ratios in a new <code>IPT-Model</code> value. It does not load or merge model weights immediately; the actual model runtimes are loaded and merged when the result is passed to <code>Load New Model</code>.</li>
  <li>Connect the result to the corresponding <code>model</code>, <code>refiner</code>, or <code>detailer</code> input of <code>Image Info Context</code> or another image-info node to retain the complete merge configuration in <code>image_info</code>, including both source model references, their model types, and the model / CLIP ratios.</li>
  <li>When that <code>image_info</code> is saved by <code>Image Saver</code> or another compatible saver, the configuration is serialized as JSON in the A1111 infotext metadata. Depending on its <code>image_info</code> field, it is written as <code>Model Merge</code>, <code>Refiner Merge</code>, or <code>Detailer Merge</code> instead of being flattened into an ordinary single-model entry.</li>
  <li>When the saved image is loaded by <code>Image Reader</code>, the merge metadata is parsed back into the corresponding <code>model</code>, <code>refiner</code>, or <code>detailer</code> value in <code>image_info</code>. <code>Image Info Context</code> can then output the restored <code>IPT-Model</code> value for reuse with <code>Load New Model</code>.</li>
  <li>The metadata stores the merge configuration, not the merged model weights. The referenced source model files must therefore be available locally when the configuration is loaded and executed again.</li>
  <li><code>base_model</code> and <code>merge_model</code> must both be checkpoints or both be diffusion models; mixing the two model types is not supported.</li>
  <li><code>model_ratio</code> controls the model merge from the base model at <code>0.0</code> to the second model at <code>1.0</code>. For checkpoints, <code>clip_ratio</code> independently controls the CLIP merge over the same range.</li>
  <li>Checkpoint merges retain the VAE from <code>base_model</code>. For diffusion models, <code>clip_ratio</code> is ignored and CLIP / VAE can be supplied to <code>Load New Model</code> as needed.</li>
</ul>
<br clear="left">

### Release Memory

<a href="assets/readme/release-memory.webp"><img align="left" hspace="16" src="assets/readme/release-memory.webp" alt="Release Memory" width="210"></a>
<ul>
  <li><code>Release Memory</code> releases selected persistent runtime references and requests Python / CUDA cleanup after the step connected to <code>after</code> has completed.</li>
  <li>The <code>after</code> input and <code>then</code> output are pass-through sockets, so the node can be placed near the end of a workflow without changing the data being passed onward.</li>
  <li><code>Generation Runtime</code> unloads ComfyUI generation models where possible and clears this extension's <code>Use Loaded Model</code> cache and recently loaded VAE runtime.</li>
  <li><code>SAM3 Runtime</code> clears the SAM3 Prompt To Mask processor cache, while <code>Tagger Runtime</code> clears PixAI Tagger and OppaiOracle Tagger torch model caches.</li>
  <li><code>GC &amp; CUDA Cleanup</code> runs garbage collection and asks the available CUDA cleanup hooks to release allocator-held memory where possible.</li>
  <li>The <code>Release Now</code> button performs the same cleanup manually when no prompt is currently running.</li>
</ul>
<br clear="left">

### Selector Nodes

<a href="assets/readme/selector-nodes.webp"><img align="left" hspace="16" src="assets/readme/selector-nodes.webp" alt="Selector nodes" width="210"></a>
<ul>
  <li>Selector nodes centralize choices for reusable workflow inputs such as checkpoints, diffusion models, LoRAs, CLIP models, VAEs, samplers, and schedulers.</li>
  <li>Model-related selectors include <code>Checkpoint Selector</code>, <code>Diffusion Model Selector</code>, <code>Unet Model Selector</code>, <code>Lora Selector</code>, <code>Vae Selector</code>, <code>CLIP Selector</code>, <code>Dual CLIP Selector</code>, <code>Triple CLIP Selector</code>, and <code>Quadruple CLIP Selector</code>.</li>
  <li>Supported model-related selectors provide a right-click <code>View Model Info...</code> action that uses the selected asset's SHA256 as a key to fetch metadata from Civitai and display it in a model information window.</li>
  <li>For <code>Lora Selector</code>, <code>View Model Info...</code> can also show a LoRA tag list with tag frequencies when metadata has been analyzed for the selected LoRA.</li>
  <li>Common connection targets include <code>Image Info Defaults</code>, <code>Image Info Context</code>, <code>Load New Model</code>, <code>Use Loaded Model</code>, and <code>XY Plot Modifier</code>.</li>
</ul>
<br clear="left">

## Workflow Examples

### Save Images With Metadata Using `Image Saver`

<a href="assets/readme/wf-sample1.webp"><img src="assets/readme/wf-sample1.webp" alt="Workflow sample: save images with metadata using Image Saver" width="900"></a>

Use `Image Saver` at the end of a generation workflow to save images with reusable metadata. The embedded `A1111 infotext` / `image_info` keeps prompt, model, LoRA, sampler, and related settings available for later reuse.

### Generate From Metadata Loaded by `Image Reader`

<a href="assets/readme/wf-sample2.webp"><img src="assets/readme/wf-sample2.webp" alt="Workflow sample: generate from metadata loaded by Image Reader" width="900"></a>

Load a metadata-rich image with `Image Reader`, pass the restored `image_info` into the workflow, and generate from the saved settings as a starting point for reproduction or further iteration.

## License

- The original source code of this project is offered under [GPL-3.0-or-later](LICENSE).
- This repository also includes vendored `sam3`, which is distributed under the [SAM License](vendor/LICENSE.sam3).
- See [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md) for third-party license details, including notes on separately obtained optional models.
- Model files and other external assets obtained separately by users remain subject to their respective upstream licenses and terms.
